from pymongo import MongoClient
from bson.objectid import ObjectId

# MongoDB Connection Variables
USER = 'aacuser'
PASS = 'password'
HOST = 'nv-desktop-services.apporto.com'
PORT = 31918
DB = 'aac'
COL = 'animals'

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource={DB}')
        self.database = self.client[DB]

    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)
            return True
        else:
            return False

    def read(self, search):
        results = []
        if search is not None:
            results = list(self.database.animals.find(search))
        #print(f"Read Results for {search}:", results)
        return results
            
    def update(self, search, new_values):
        if search is not None and new_values is not None:
            update_result = self.database.animals.update_one(search, new_values)
            return update_result.modified_count > 0  # returns True if at least one document was updated
        else:
            return False
            
    def delete(self, remove):
        if remove is not None:
            delete_result = self.database.animals.delete_one(remove)
            return delete_result.deleted_count > 0  # returns True if at least one document was deleted
        else:
            return False
